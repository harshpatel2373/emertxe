/*
 *name : harsh dineshkumar patel
 * date: 3/02/2022
 * description:A28 - Implement a LED dimmer application using PWM (Time ISR Based)
 */

#include <xc.h>
#include "matrix_keypad.h"
#include "clcd.h"


#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

static void init_config(void) {
    TRISB = 0;
    //PORTB = 0x00;
    init_matrix_keypad();
    init_clcd();
    clcd_print("duty cycle cntrl",LINE1(0));
}

void main(void) {
    
    
    
    unsigned char key;
    static unsigned long int period = 100, duty_cycle = 50,loop_counter = 0, wait = 0;
    init_config();
    while (1) 
    {
        
        key = read_matrix_keypad(LEVEL);
        
        //if (wait-- == 0)
        //{
            wait = 100;

            if (key == 1)
            {
                if(duty_cycle != period)
                {
                    //clcd_putch(0xFF, LINE1(0));
                    duty_cycle++;
                }
            }
            else if(key == 2)
            {
                if (duty_cycle != 0)
                {
                    duty_cycle--;
                }
            }
        //}
        if (loop_counter < duty_cycle)
        {
            RB7 = 1;
        }
        else if (loop_counter > duty_cycle)
        {
            RB7 = 0;
        }
        if(loop_counter++ == period)
        {
            loop_counter = 0;
        }
        
        for(int i = 0; i <= ((duty_cycle * 15)/100); i++)
            clcd_putch(0xFF, LINE2(i));
        for(int i = 15; i > ((duty_cycle*15)/100); i--)
            clcd_putch(0x00, LINE2(i));
    }

}
