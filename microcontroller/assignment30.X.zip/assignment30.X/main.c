/*
 * name: harsh dineshkumar patel
 * date: 03/02/2022
 * description: A30 - Implement a key detection feedback using UART
 */

#include <xc.h>
#include "uart.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

#define LED_ARARY1          PORTD
#define LED_ARRAY1_DDR      TRISD
#define LED1                RD0

extern unsigned char ch;

static void init_config(void) {
    
    
    init_uart(9600);
    init_digital_keypad();
    puts("UART Test Code\n\r");
    
    /* Enabling peripheral interrupt */
    PEIE = 1;
    
    /* Enabling global interrupt */
    GIE = 1;
}

void main(void) {
    unsigned long int wait = 0;
    unsigned char key;
    init_config();

    while (1) {
        key = read_digital_keypad(STATE);
        if(key == SW1)
        {
            puts("KEY 1 IS PRESSED\n\r");
        }
        else if(key == SW2)
        {
            puts("KEY 2 IS PRESSED\n\r");
        }
        else if(key == SW3)
        {
            puts("KEY 3 IS PRESSED\n\r");
        }
        else if(key == SW4)
        {
            puts("KEY 4 IS PRESSED\n\r");
        }
        
    }
    
    return;
}
