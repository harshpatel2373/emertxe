/*name: harsh dineshkumar patel
 * date:29/01/2022
 * description:A21 - Implement a Stop Watch with 5 laps
 */

#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include <string.h>
#include "timers.h"
#pragma config WDTE = OFF
extern int change;

static void clcd_write(unsigned char byte, unsigned char mode)
{
    CLCD_RS = mode;
    
    CLCD_DATA_PORT = byte & 0xF0;
    CLCD_EN = HI;
    __delay_us(100);
    CLCD_EN = LOW;

    CLCD_DATA_PORT = (byte & 0x0F) << 4;
    CLCD_EN = HI;
    __delay_us(100);
    CLCD_EN = LOW;
    
    __delay_us(4100);
}

/* function to initialize matrix keypad and clcd */
static void init_config(void)
{
	init_matrix_keypad();
	init_clcd();
    GIE = 1;
    init_timer0();
    
}
void main(void)
{
    char msg[] = "00:00:00:00", msg1[12],msg2[12],msg3[12],msg4[12],msg5[12];
    long int count = -1, once, count1 = -1;
    init_config();
    clcd_print(msg,LINE1(0));
    
    unsigned char key;
    short int flag = 0;
    while(1)
    {
        key = read_matrix_keypad(STATE);
 
        if(key == 1)
        {
            flag = !flag;
            TMR0IE = !TMR0IE;
            if(once == 1)
            {
                TMR0IE = 1;
                once = 0;
            }
            
        }
        if(key == 2)
        {
            count = (count  + 1) % 5;
            switch(count)
            {
                case 0:
                    strcpy(msg1, msg);
                    clcd_print(msg1,LINE2(0));
                    break;
                case 1:
                    strcpy(msg2, msg);
                    clcd_print(msg2,LINE2(0));
                    break;
                case 2:
                    strcpy(msg3, msg);
                    clcd_print(msg3,LINE2(0));
                    break;
                case 3:
                    strcpy(msg4, msg);
                    clcd_print(msg4,LINE2(0));
                    break;
                case 4:
                    strcpy(msg5, msg);
                    clcd_print(msg5,LINE2(0));
                    break;       
            }
        }
        if(key == 2 && flag == 0)
        {
            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
            strcpy(msg,"00:00:00:00");
            clcd_print(msg,LINE1(0));
            strcpy(msg1,"");
            strcpy(msg2,"");
            strcpy(msg3,"");
            strcpy(msg4,"");
            strcpy(msg5,"");
        }
        if(key == 3 || key == 4)
        {
            //flag= 0;
            if(key == 3)
                count1 =(count1 + 1) % 5;
            else
                count1 = (count1 - 1) % 5;
            if(count1 < 0)
                count1 = 4;
            else if(count1 > 4)
                count1 = 0;
            //clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
            switch(count1)
            {
                case 0:
                    
                    clcd_print(msg1,LINE1(0));
                    clcd_print(msg2,LINE2(0));
                    break;
                case 1:
                    
                    clcd_print(msg2,LINE1(0));
                    clcd_print(msg3,LINE2(0));
                    break;
                case 2:
                  
                    clcd_print(msg3,LINE1(0));
                    clcd_print(msg4,LINE2(0));
                    break;
                case 3:
                  
                    clcd_print(msg4,LINE1(0));
                    clcd_print(msg5,LINE2(0));
                    break;
                case 4:
                   
                    clcd_print(msg5,LINE1(0));
                    clcd_print(msg1,LINE2(0));
                    break;       
            }
          
        }
   
        if(flag == 1)
        {
             msg[10] = msg[10] + 1;
            if(msg[10] > '9')
            {
                msg[10] = '0';
                msg[9] = msg[9] + 1;
            }
            if(msg[9] > '9')
            {
                msg[9] = '0';
                            //msg[7] = msg[7] + 1;
            }
            if (change == 2)
            {
                change = 0;
               
                        msg[7] =msg[7] + 1;
                       if(msg[7] > '9')
                        {
                            msg[7] = '0';
                            msg[6] = msg[6] + 1;
                        }
                        if(msg[6] > '9')
                        {
                            msg[6] = '0';
                            msg[4] = msg[4] + 1;
                        }
                        if(msg[4] > '9')
                        {
                            msg[4] = '0';
                            msg[3] = msg[3] + 1;
                       }
                       if(msg[3] > '9')
                       {
                            msg[3] = '0';
                            msg[1] = msg[1] + 1;
                        }
                        if(msg[1] > '9')
                        {
                            msg[1] = '0';
                            msg[0] = msg[0] + 1;
                        }
                        if(msg[0] > '9')
                        {
                            msg[0] = 0;
                        }
            }
             clcd_print(msg,LINE1(0));
        }
                                        
       
    
    }
}

