/*
 * name: harsh dineshkumar patel
 * date: 03/02/2022
 * description: A08 - Implement a LED dimmer application using PWM (Timer ISR Based)
 */

#include <xc.h>
#include "main.h"
#include "adc.h"
#include "pwm.h"
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

void glow_led(unsigned short duty_cycle)
{
    /*changing duty cycle according to adc data*/
    static unsigned long int loop_counter = 0, period = 100, wait = 0;
   
    if (loop_counter < duty_cycle)
        {
            RD0 = 1;
        }
        else if (loop_counter > duty_cycle)
        {
            RD0 = 0;
        }
        if(loop_counter++ == period)
        {
            loop_counter = 0;
        }

    set_pwm_duty(duty_cycle);
}
/*intializing led and adc*/
static void init_config(void) {
    LED_ARRAY1 = OFF;
    LED_ARRAY1_DDR = 0x00;
    init_adc();
    init_pwm();
}

void main(void) {
    unsigned short adc_reg_val; //0 to 1023
    
    init_config();

    while (1) {
        /*receving data from adc*/
        adc_reg_val = read_adc();//10 bits -> 0 to 1023
        /*giving data to glow led*/
        glow_led(adc_reg_val / 10);
    }
    return;
}
