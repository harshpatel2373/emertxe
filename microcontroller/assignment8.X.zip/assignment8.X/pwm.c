
#include<xc.h>
void init_pwm(void)
{
    /*TO SET CCP PIN RC2 AS OUTPUT*/
    TRISC2 = 0;
    /*SETTING TIMER2 SCALLING VALUE 1:4*/
    T2CKPS0 =0;
    T2CKPS0 = 0;
    /*TO GENRATE PWM OF FREQUENCY*/
    PR2 = 249;
    TMR2ON = 1;
    /*TO CONFIGURE MODULE INTO PWM MODE*/
    CCP1CON =0X0C;
}
void set_pwm_duty(unsigned char duty_cycle)
{
    unsigned int reg_val;
    reg_val = ((float)duty_cycle / 100) * 250 * 4;
    CCPR1L = reg_val >> 2;
    CCP1CON =(CCP1CON & 0xCF) | ((reg_val & 0x03) << 4);
}

