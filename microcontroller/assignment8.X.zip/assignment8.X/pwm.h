/* 
 * File:   pwm.h
 * Author: harsh
 *
 * Created on 31 January, 2022, 7:58 AM
 */

#ifndef PWM_H
#define	PWM_H

void init_pwm(void);
void set_pwm_duty(unsigned char duty_cycle);
#endif	/* PWM_H */

